<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Add Employee</h4>
            <div>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Approx</a></li>
                    <li class="breadcrumb-item"><a href="#">Forms</a></li>
                    <li class="breadcrumb-item active">Elements</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h4 class="card-title">Employee Form</h4>
                    </div>
                </div>
            </div>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>  
             <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
            <div class="card-body pt-0">
                <form action="<?php echo e(route('admin.employee.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <input type="hidden" name="company_id" value="1">
                        <input type="hidden" name="role" value="employee">

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputname" class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"  id="exampleInputname" placeholder="Enter name">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputphone" class="form-label">Phone</label>
                                <input type="tel" class="form-control" name="phone"  value="<?php echo e(old('phone')); ?>" id="exampleInputphone" placeholder="Enter phone number">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" class="form-control" name="email"  value="<?php echo e(old('email')); ?>"id="exampleInputEmail1" placeholder="Enter email">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Enter password">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputPassword2" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation" id="exampleInputPassword2" placeholder="Confirm password">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputaddress" class="form-label">Address</label>
                                <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" id="exampleInputaddress" placeholder="Enter address">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputdesignation" class="form-label">Designation</label>
                                <input type="text" class="form-control" name="designation"  value="<?php echo e(old('designation')); ?>"id="exampleInputdesignation" placeholder="Enter designation">
                            </div>
                        </div>

                       <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputjoin date" class="form-label">Join date</label>
                                <input type="date" class="form-control" name="join date" value="<?php echo e(old('join date')); ?>" id="exampleInputjoin date" placeholder="Join date">
                            </div>
                        </div>

                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputstatus" class="form-label">Status</label>
                            <select class="form-control" name="status" value="<?php echo e(old('status')); ?>" id="">
                                <option value=""selected disabled>--select--</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                            </div>
                        </div>
                        <div class="col-4">
    <div class="mb-3">
        <label for="department_id" class="form-label">Department</label>
        <select class="form-control" name="department_id" id="department_id" required>
            <option value="" disabled>-- Select Department --</option>
            <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($department->id); ?>" 
                    <?php echo e($department->department_id == $department->id ? 'selected' : ''); ?>>
                    <?php echo e($department->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="" disabled>No departments found</option>
            <?php endif; ?>
        </select>
    </div>
</div>


                        <div class="col-4">
                            <div class="mb-3">
                                <label for="exampleInputavatar" class="form-label">Avatar</label>
                                <input type="file" class="form-control" name="avatar" value="<?php echo e(old('avatar')); ?>" id="exampleInputavatar" placeholder="Avatar">
                            </div>
                        </div>
                    </div>

                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-danger">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xampp\htdocs\LMS\resources\views/Admin/Employee/create.blade.php ENDPATH**/ ?>