<div class="startbar d-print-none">
        <!--start brand-->
        <div class="brand">
            <a href="#" class="logo">
                <span>
                    
                </span>
                <span class="">
                    
                    
                </span>
            </a>
        </div>
        <!--end brand-->
        <!--start startbar-menu-->
        <div class="startbar-menu" >
            <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
                <div class="d-flex align-items-start flex-column w-100">
                    <!-- Navigation -->
                    <ul class="navbar-nav mb-auto w-100">
                        <li class="menu-label mt-2">
                            <span>Main</span>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                                <i class="iconoir-report-columns menu-icon"></i>
                                <span>Dashboard</span>
                                
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.employee.index')); ?>">
                                <i class="iconoir-hand-cash menu-icon"></i>
                                <span>Employee</span>
                            </a>
                        </li>
                        <!--end nav-item-->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.department.index')); ?>">
                                <i class="iconoir-hand-cash menu-icon"></i>
                                <span>Department</span>
                            </a>
                        </li><!--end nav-item--> 
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="iconoir-group menu-icon"></i>
                                <span>Clients</span>
                            </a>
                        </li><!--end nav-item-->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.leavetype.index')); ?>">
                                <i class="iconoir-book menu-icon"></i>
                                <span>Leave</span>
                            </a>
                        </li><!--end nav-item-->
                        <!--end nav-item-->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.holiday.index')); ?>">
                             <i class="iconoir-calendar menu-icon"></i>
                                <span>Holiday</span>
                            </a>
                        </li><!--end nav-item-->
                        

                    </ul><!--end navbar-nav--->

                </div>
            </div><!--end startbar-collapse-->
        </div><!--end startbar-menu-->
    </div><!--end startbar-->
    <div class="startbar-overlay d-print-none"></div>
<?php /**PATH D:\Xampp\htdocs\LMS\resources\views/Admin/Layouts/partials/sidebar.blade.php ENDPATH**/ ?>