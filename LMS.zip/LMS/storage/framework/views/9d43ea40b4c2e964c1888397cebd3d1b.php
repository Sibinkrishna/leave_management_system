

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Edit Employee</h4>
            <div>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Approx</a></li>
                    <li class="breadcrumb-item"><a href="#">Forms</a></li>
                    <li class="breadcrumb-item active">Elements</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h4 class="card-title">Employee Form</h4>
                    </div>
                </div>
            </div>

            <!-- Validation Errors -->
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>  

            <!-- Success Message -->
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <div class="card-body pt-0">
                <form action="<?php echo e(route('admin.employee.update', $employee->id )); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <!-- Hidden fields -->
                        <input type="hidden" name="company_id" value="1">
                        <input type="hidden" name="role" value="employee">

                        <!-- Name -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="nameInput" class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $employee->name)); ?>" id="nameInput" placeholder="Enter name">
                            </div>
                        </div>

                        <!-- Phone -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="phoneInput" class="form-label">Phone</label>
                                <input type="tel" class="form-control" name="phone" value="<?php echo e(old('phone', $employee->phone)); ?>" id="phoneInput" placeholder="Enter phone number">
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="emailInput" class="form-label">Email address</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $employee->email)); ?>" id="emailInput" placeholder="Enter email">
                            </div>
                        </div>

                        <!-- Address -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="addressInput" class="form-label">Address</label>
                                <input type="text" class="form-control" name="address" value="<?php echo e(old('address', $employee->address)); ?>" id="addressInput" placeholder="Enter address">
                            </div>
                        </div>

                        <!-- Designation -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="designationInput" class="form-label">Designation</label>
                                <input type="text" class="form-control" name="designation" value="<?php echo e(old('designation', $employee->designation)); ?>" id="designationInput" placeholder="Enter designation">
                            </div>
                        </div>

                        <!-- Join Date -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="joinDateInput" class="form-label">Join Date</label>
                                <input type="date" class="form-control" name="join_date" value="<?php echo e(old('join_date', $employee->join_date)); ?>" id="joinDateInput" placeholder="Join Date">
                            </div>
                        </div>

                        <!-- Department -->
                       <div class="col-4">
    <div class="mb-3">
        <label for="departmentSelect" class="form-label">Department</label>
        <select class="form-control" name="department_id" id="departmentSelect">
            <option value="" selected disabled>--select--</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>" <?php if($employee->department_id == $department->id): ?> selected <?php endif; ?>>
                    <?php echo e($department->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>


                        <!-- Status -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="statusSelect" class="form-label">Status</label>
                                <select class="form-control" name="status" id="statusSelect">
                                    <option value="" selected disabled>--select--</option>
                                    <option value="active" <?php echo e((old('status', $employee->status ?? '') === 'active') ? 'selected' : ''); ?>>Active</option>
                                    <option value="inactive" <?php echo e((old('status', $employee->status ?? '') === 'inactive') ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <!-- Avatar -->
                        <div class="col-4">
                            <div class="mb-3">
                                <label for="avatarInput" class="form-label">Avatar</label>
                                <input class="form-control" type="file" name="avatar" id="avatarInput">
                            </div>
                        </div>

                    </div> <!-- row -->

                    <!-- Buttons -->
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-danger">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xampp\htdocs\LMS\resources\views/Admin/Employee/edit.blade.php ENDPATH**/ ?>