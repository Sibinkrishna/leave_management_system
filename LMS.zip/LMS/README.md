<h4>Leave Management System</h4>
step-1: .env change to your database name.
step-2: php artisan migrate
step-3: php artisan serv
